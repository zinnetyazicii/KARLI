<?php
if(@$_SESSION["user"]){ ?>
</div> <!-- maincont-->
</div> <!-- Container-->
</div> <!-- Container-->
</div> <!-- Container-->
</div> <!-- Dashboard-->
<?php } ?>
	<div class="actionout">
		<div class="action">
		</div>
	</div>
	
		
	<div class="mymodal">
		<div class="mymodalin">
		<div class="mymodelhead"></div><hr>
		<div class="mymodelcontent"></div><hr>		
		<a id="modalevetbtn" class="btn btn-warning" style="float:right; margin-left:10px;" href="javascript:void(0)">Evet</a>
		<a id="modalsilbtn" class="btn btn-danger" style="float:right; margin-left:10px;" href="javascript:void(0)">Sil</a>
		<a id="modalkapatbtn" class="btn btn-primary" href="javascript:void(0)" style="float:right;">Kapat</a>			
		</div>
	</div>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?php echo $url; ?>/js/nav.js"></script>

</body>

</html>