
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">    
    <div class="carousel-item">
      <img src="https://migros-dali-storage-prod.global.ssl.fastly.net/tazedirekt/brand/list/10000000000367/karali-602afb.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <br>
  <div class="carousel-inner">    
    <div class="carousel-item">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb0PEEkdfKAl4Leo9N_Y0Lu2ppsdZnHoXaSvU59PQVNw7rJfrPLZG52v7r-iisSejW1-s&usqp=CAU" class="d-block w-100" alt="...">
    </div>
  </div>

</div>


